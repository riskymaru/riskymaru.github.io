"use strict";

class Config{

	constructor(){

        this.gameDimension;

        this.pixiSettings = {
        						legacy:'true',
							    width: 1024, 
							    height: 768, 
							    backgroundColor: 0x0, 
							    //resolution: 0.58
							}



    }
}